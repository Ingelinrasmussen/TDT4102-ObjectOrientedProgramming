#include "std_lib_facilities.h"
#include "Card.h"
#include "CardDeck.h"
#include "utilities.h"
#include "BlackJack.h"

BlackJack::BlackJack(){ // Initialiseringsliste

    cards = CardDeck();
	cards.shuffle();

    for (int i = 0; i < 2; ++i){
        playerCards.push_back(cards.drawCard());
        dealerCards.push_back(cards.drawCard());
    }
    playBlackJack();
}

int BlackJack::calculateSumDealer(vector<Card>deal){
    int sum = 0;
    int ace = 0;
    for (Card c: deal){
	    int value = c.rankVal();
        if (value <= 13 and value >= 11){
            value = 10;
        }
        else if (value == 14){
            ace += 1;
            value = 0;
        }
        sum += value;   
    }

    for (int i = 0; i < ace; ++i){
        if (sum + 11 <= 21){
            sum += 11;
        }
        else{
            sum += 1;
        }
    }
    return sum;
}

void BlackJack::playBlackJack(){
    cout << "\nWelcome to BlackJack!\nYour cards are: \n";

    for (Card el : playerCards){
        cout << el.toString() << "\n";
    }
    int sum = calculateSum(playerCards);
    cout << "Your sum is " << sum << "\n";

    Card visibleCard = dealerCards[0];
    cout << "\nDealers visible card is: " << visibleCard.toString() << "\n";

    cout << "\nWould you like to get another card? (yes/no) ";
    string answer = "";
    cin >> answer;
    bool dealer = true;
    int sumD = calculateSumDealer(dealerCards);
    int outcome = 0;

    if (sumD >= 17){
        dealer = false;
    }

    if (answer == "yes"){

        do{
            playerCards.push_back(cards.drawCard());
            int s = playerCards.size();
            cout << "\nYour new card is " << playerCards[s-1].toString() << "\n";

            cout << "\nYour hand is now: \n";

            for (Card el : playerCards){
                cout << el.toString() << "\n";
            }

            sum = calculateSum(playerCards);
            cout << "New sum is: " << sum << "\n";

            if (dealer == true){
                dealerCards.push_back(cards.drawCard());
                sumD = calculateSum(playerCards);
                if (sumD >= 17){
                    dealer = false;
                }
            }

            if (sum > 21 and sumD <= 21){
                cout << "\nYou lost! You got " << sum << " which is over 21.\nDealer got " << sumD << "\n";
                outcome = 1;
                break;
            }
            else if (sumD > 21 and sum <= 21){
                cout << "\nYou won! Dealer got " << sumD << " which is over 21.\nYou got " << sum << "\n";
                outcome = 1;
                break;
            }
            else if (sum == 21 and sumD != 21){
                cout << "\nYou got Blackjack! Your sum is 21! You won!\n";
                outcome = 1;
                break;
            }

            cout << "\nWould you lke to get another card? (yes/no) ";
            cin >> answer;

        } while (answer == "yes");
    }
        
    if (answer == "no" || outcome == 0){
        cout << "\nYour score is " << sum << " while dealer has " << sumD;
        if (sum > sumD and sum <= 21){
            cout << "\nYou won!";
        }
        else{
            cout << "\nYou lost!";
        }
    }
    cout << "\nThanks for playing!\n";

}

    
    

int BlackJack::calculateSum(vector<Card>cards){

    int sum{0};
    for (Card c: cards){
	    int value = c.rankVal();
        if (value >= 11 and value <= 13){
            sum += 10;
        }
        else if (value == 14){
            cout << "Do you want your ace to count as 1 or 11? ";
            int aceValue{0};
            cin >> aceValue;
            sum += aceValue;
        }
        else{
            sum += value; 
        }
    }
    return sum;
}
