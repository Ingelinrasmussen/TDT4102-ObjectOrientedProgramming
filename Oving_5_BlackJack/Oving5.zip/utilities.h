
#include "std_lib_facilities.h"
#pragma once

int randomWithLimits(int lower, int upper);