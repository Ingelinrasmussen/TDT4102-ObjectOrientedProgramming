#pragma once

void replace_v(std::vector<std::string> &v, const std::string &old, std::string replacement);
void replace_s(std::set<std::string> &s, const std::string &old, std::string replacement);
void iterator_v();
void iterator_s();